package com.example.ebayscraper;

public class eBayAPICaller {

  private static final String API = "";

}
