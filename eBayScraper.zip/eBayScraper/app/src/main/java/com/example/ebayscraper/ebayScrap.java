package com.example.ebayscraper;

import android.app.Activity;
import android.util.Log;
import android.widget.TextView;
import java.lang.ref.WeakReference;

public class ebayScrap implements ebayFunctions {

  private static final String TAG = "ebayScrap";

  @Override
  public void process(final String searchPhrase, final WeakReference<Activity> activity) {
    Log.i(TAG, "Starting our new historical thread");

    //Insert Code here


    Log.i(TAG, "Sending to display");
    //Output to display
    activity
        .get()
        .runOnUiThread(
            new Runnable() {
              @Override
              public void run() {
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle1)).setText("Item:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue1)).setText(searchPhrase);
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle2)).setText("Current High:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue2)).setText("$" + "99.99");
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle3)).setText("Current Low:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue3)).setText("$" + "9.99");
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle4)).setText("Total Count:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue4)).setText("$" + "99.99");
              }
            });
  }
}
