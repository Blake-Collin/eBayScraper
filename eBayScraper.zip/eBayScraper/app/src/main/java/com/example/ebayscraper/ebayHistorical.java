package com.example.ebayscraper;

import android.app.Activity;
import android.util.Log;
import android.widget.TextView;
import java.lang.ref.WeakReference;

public class ebayHistorical implements ebayFunctions {

  private static final String TAG = "ebayHistorical";

  @Override
  public void process(final String searchPhrase, final WeakReference<Activity> activity) {
    Log.i(TAG, "Starting our new historical thread");


    // Insert code here


    Log.i(TAG, "Sending to display");
    //Output to display
    activity
        .get()
        .runOnUiThread(
            new Runnable() {
              @Override
              public void run() {
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle1)).setText("Item:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue1)).setText(searchPhrase);
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle2)).setText("Historical Average:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue2)).setText("$" + "9.99");
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle3)).setText("Historical Low:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue3)).setText("$" + "99.99");
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle4)).setText("Historical High:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue4)).setText("$" + "99.99");
                ((TextView) activity.get().findViewById(R.id.textViewFieldTitle5)).setText("Total Count:");
                ((TextView) activity.get().findViewById(R.id.textViewFieldValue5)).setText("1265");
              }
            });
  }
}
